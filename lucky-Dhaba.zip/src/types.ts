export type Language = 'en' | 'hi';

export interface MenuItem {
  id: string;
  nameEn: string;
  nameHi: string;
  price: number;
  descriptionEn: string;
  descriptionHi: string;
  image: string; // Placeholder or icon representation
  tagEn: string;
  tagHi: string;
}

export interface CartItem {
  menuItem: MenuItem;
  quantity: number;
}

export interface Testimonial {
  id: string;
  name: string;
  roleEn: string;
  roleHi: string;
  commentEn: string;
  commentHi: string;
  rating: number;
  date: string;
}

export interface DhabaStatus {
  isOpen: boolean;
  messageEn: string;
  messageHi: string;
  colorClass: string;
  nextEventTime: string;
}
