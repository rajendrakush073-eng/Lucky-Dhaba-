import { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { MenuSection } from './components/MenuSection';
import { OrderCalculator } from './components/OrderCalculator';
import { Facilities } from './components/Facilities';
import { Testimonials } from './components/Testimonials';
import { AddressMap } from './components/AddressMap';
import { AboutSection } from './components/AboutSection';
import { Language, CartItem, MenuItem, DhabaStatus } from './types';
import { checkDhabaStatus } from './utils';
import { TRANSLATIONS } from './data';
import { Heart, Sparkles, Phone, MessageSquare } from 'lucide-react';

export default function App() {
  const [lang, setLang] = useState<Language>('hi'); // Default to Hindi since the Dhaba serves local Delhi Hindi speakers beautifully
  const [cart, setCart] = useState<CartItem[]>([]);
  const [serviceMode, setServiceMode] = useState<'dinein' | 'takeaway'>('takeaway');
  const [instructions, setInstructions] = useState<string>('');
  const [status, setStatus] = useState<DhabaStatus>(() => checkDhabaStatus(new Date()));

  const t = TRANSLATIONS[lang];

  // Keep business status fresh by evaluating current local time relative to opening schedules
  useEffect(() => {
    const interval = setInterval(() => {
      setStatus(checkDhabaStatus(new Date()));
    }, 15000); // Check every 15 seconds to ensure real-time accuracy

    return () => clearInterval(interval);
  }, []);

  // Update item quantity inside our virtual Dhaba plate
  const handleUpdateQuantity = (item: MenuItem, quantity: number) => {
    if (quantity <= 0) {
      setCart((prev) => prev.filter((i) => i.menuItem.id !== item.id));
    } else {
      setCart((prev) => {
        const exists = prev.find((i) => i.menuItem.id === item.id);
        if (exists) {
          return prev.map((i) => (i.menuItem.id === item.id ? { ...i, quantity } : i));
        } else {
          return [...prev, { menuItem: item, quantity }];
        }
      });
    }
  };

  // Completely drop single item from plate
  const handleRemoveItem = (item: MenuItem) => {
    setCart((prev) => prev.filter((i) => i.menuItem.id !== item.id));
  };

  // Reset order plate completely
  const handleClearCart = () => {
    setCart([]);
    setInstructions('');
  };

  const totalCartQuantity = cart.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <div className="min-h-screen bg-stone-50 font-sans text-stone-900 selection:bg-amber-500 selection:text-stone-950 flex flex-col justify-between">
      <div>
        {/* Header Block: Hero, quick info ribbon, lang toggler */}
        <Header lang={lang} setLang={setLang} status={status} />

        {/* Floating Quick Action Trigger for easier mobile ordering */}
        {totalCartQuantity > 0 && (
          <div className="fixed bottom-6 right-6 z-40 animate-bounce">
            <a
              href="#lucky-dhaba-order-section"
              className="flex items-center gap-2 bg-amber-500 text-stone-950 font-black px-4.5 py-3 rounded-full shadow-2xl border border-amber-600 hover:bg-amber-400 hover:scale-105 active:scale-95 transition-all text-xs uppercase"
            >
              <span>🍛 View Plate ({totalCartQuantity})</span>
            </a>
          </div>
        )}

        {/* Detailed Authentic Menu Selection section */}
        <MenuSection lang={lang} cart={cart} onUpdateQuantity={handleUpdateQuantity} />

        {/* Interactive Steel Thali Order Checkout tool */}
        <OrderCalculator
          lang={lang}
          cart={cart}
          serviceMode={serviceMode}
          setServiceMode={setServiceMode}
          instructions={instructions}
          setInstructions={setInstructions}
          onClearCart={handleClearCart}
          onRemoveItem={handleRemoveItem}
        />

        {/* Interactive Story Section of Founder Rajendra Kushwaha */}
        <AboutSection lang={lang} />

        {/* Customer Amenities (Free cold water, Dine-in etc) */}
        <Facilities lang={lang} />

        {/* Timings timetable & copyable physical address */}
        <AddressMap lang={lang} />

        {/* Highly convincing Customer reviews & testimonials */}
        <Testimonials lang={lang} />
      </div>

      {/* Main Footer credit */}
      <footer className="bg-stone-950 text-stone-400 py-10 px-4 border-t border-stone-800 text-center text-xs">
        <div className="max-w-6xl mx-auto flex flex-col items-center gap-4">
          <div className="flex items-center gap-1.5 text-stone-300 font-extrabold text-sm">
            <span>{t.heroTitle}</span>
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
            <span>{t.byOwner}</span>
          </div>

          <p className="max-w-md text-stone-500 leading-relaxed text-[11px] sm:text-xs">
            {lang === 'en'
              ? 'Address: 8/75, Gali No. 8, Industrial Area, Anand Parbat, Nai Basti, New Delhi - 110005'
              : 'पता: 8/75, गली नंबर 8, इंडस्ट्रियल एरिया, आनंद पर्वत, नई बस्ती, नई दिल्ली - 110005'}
          </p>

          <p className="flex items-center gap-1 text-[11px]" id="footer-designer-tagline">
            <span>{t.allRightsReserved} • Made with</span>
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-current" />
            <span>in New Delhi</span>
          </p>

          <div className="flex gap-4 items-center justify-center mt-2 border-t border-stone-900 pt-4 w-full text-stone-600">
            <a href="tel:+917982560692" className="hover:text-amber-500 flex items-center gap-1">
              <Phone className="w-3.5 h-3.5" /> +91 7982560692
            </a>
            <span>•</span>
            <a href="https://wa.me/917982560692" target="_blank" rel="noreferrer" className="hover:text-emerald-500 flex items-center gap-1">
              <MessageSquare className="w-3.5 h-3.5" /> Chat
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
