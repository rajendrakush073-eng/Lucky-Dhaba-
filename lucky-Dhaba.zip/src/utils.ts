import { DhabaStatus, CartItem } from './types';

/**
 * Normalizes any Date object to Indian Standard Time (UTC + 5:30)
 */
export const getISTTime = (now: Date = new Date()): Date => {
  const utc = now.getTime() + (now.getTimezoneOffset() * 60000);
  const ist = new Date(utc + (3600000 * 5.5));
  return ist;
};

/**
 * Evaluates whether the Dhaba is open at the current time or a custom time in IST
 */
export const checkDhabaStatus = (now: Date = new Date()): DhabaStatus => {
  const istDate = getISTTime(now);
  const day = istDate.getDay(); // 0 = Sunday, 1 = Monday, ..., 6 = Saturday
  const hours = istDate.getHours();
  const minutes = istDate.getMinutes();
  const currentTimeDec = hours + minutes / 60; // Represent time as 14.5 for 2:30 PM

  // Check Monday Timings
  if (day === 1) {
    const isLunch = currentTimeDec >= 9 && currentTimeDec < 15;
    const isDinner = currentTimeDec >= 19 && currentTimeDec < 21;

    if (isLunch) {
      return {
        isOpen: true,
        messageEn: 'Open Now for Monday Lunch (Closes at 03:00 PM IST)',
        messageHi: 'सोमवार दोपहर भोजन के लिए खुला है (दोपहर 03:00 बजे तक)',
        colorClass: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
        nextEventTime: '15:00'
      };
    } else if (isDinner) {
      return {
        isOpen: true,
        messageEn: 'Open Now for Monday Dinner (Closes at 09:00 PM IST)',
        messageHi: 'सोमवार रात के भोजन के लिए खुला है (रात 09:00 बजे तक)',
        colorClass: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
        nextEventTime: '21:00'
      };
    } else {
      // It is Monday but not during lunch/dinner periods
      let nextOpeningEn = 'Opens tonight at 07:00 PM IST';
      let nextOpeningHi = 'आज रात 07:00 बजे पुनः खुलेगा';
      if (currentTimeDec >= 21) {
        nextOpeningEn = 'Opens tomorrow at 09:00 AM IST';
        nextOpeningHi = 'कल सुबह 09:00 बजे खुलेगा';
      } else if (currentTimeDec < 9) {
        nextOpeningEn = 'Opens today at 09:00 AM IST';
        nextOpeningHi = 'आज सुबह 09:00 बजे खुलेगा';
      }

      return {
        isOpen: false,
        messageEn: `Currently Closed. ${nextOpeningEn}`,
        messageHi: `अभी बंद है। ${nextOpeningHi}`,
        colorClass: 'bg-rose-500/10 text-rose-600 border-rose-500/20',
        nextEventTime: currentTimeDec < 9 ? '09:00' : (currentTimeDec < 15 ? '19:00' : '明天 09:00')
      };
    }
  }

  // Tuesday to Sunday Timings (09:00 AM to 11:00 PM)
  const isNormalDayOpen = currentTimeDec >= 9 && currentTimeDec < 23;

  if (isNormalDayOpen) {
    return {
      isOpen: true,
      messageEn: 'Open Now! (Closes at 11:00 PM IST)',
      messageHi: 'ढाबा खुला है! (रात 11:00 बजे तक उपलब्ध)',
      colorClass: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
      nextEventTime: '23:00'
    };
  } else {
    let nextOpeningEn = 'Opens at 09:00 AM IST';
    let nextOpeningHi = 'सुबह 09:00 बजे खुलता है';
    return {
      isOpen: false,
      messageEn: `Dhaba is Closed. ${nextOpeningEn}`,
      messageHi: `ढाबा अभी बंद है। ${nextOpeningHi}`,
      colorClass: 'bg-rose-500/10 text-rose-600 border-rose-500/20',
      nextEventTime: '09:00'
    };
  }
};

/**
 * Compiles absolute order payload and returns the url-encoded WhatsApp API link
 */
export const formatWhatsAppOrderLink = (
  cart: CartItem[],
  serviceMode: 'dinein' | 'takeaway',
  specialInstructions: string,
  phoneNumber: string = '917982560692'
): string => {
  const totalAmount = cart.reduce((acc, item) => acc + item.menuItem.price * item.quantity, 0);
  
  let text = `*लकी ढाबा (Lucky Dhaba) - आर्डर सन्देश* 🍽️\n`;
  text += `===============================\n\n`;
  
  cart.forEach((item, index) => {
    const itemTotal = item.menuItem.price * item.quantity;
    text += `${index + 1}. *${item.menuItem.nameHi}* (${item.menuItem.nameEn})\n`;
    text += `   मसालेदार स्वाद x ${item.quantity} = *₹${itemTotal}*\n`;
  });
  
  text += `\n===============================\n`;
  text += `*कुल रकम (Grand Total)*: ₹${totalAmount}\n`;
  text += `*सर्विंग मोड (Order Type)*: ${serviceMode === 'dinein' ? 'बैठने की बढ़िया व्यवस्था (Dine-in)' : 'पैकिंग करके लें जाना (Takeaway)'}\n`;
  
  if (specialInstructions.trim()) {
    text += `*स्वाद निर्देश (Custom Note)*: "${specialInstructions}"\n`;
  }
  
  text += `\n-------------------------------\n`;
  text += `*भेजने वाले का नाम व पता (Customer Name/Address)*: [यहाँ अपना नाम और एड्रेस लिखें (Write name & table no. or address)]\n\n`;
  text += `राजेंद्र भाई, कृपया मेरा आर्डर तैयार रखें। धन्यवाद! 🙏`;

  const encodedText = encodeURIComponent(text);
  return `https://wa.me/${phoneNumber}?text=${encodedText}`;
};
