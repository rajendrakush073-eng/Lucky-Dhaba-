import React, { useState } from 'react';
import { MapPin, Copy, CheckCircle, ExternalLink, Calendar, Compass, PhoneCall } from 'lucide-react';
import { Language } from '../types';
import { TRANSLATIONS } from '../data';

interface AddressMapProps {
  lang: Language;
}

export const AddressMap: React.FC<AddressMapProps> = ({ lang }) => {
  const t = TRANSLATIONS[lang];
  const [copied, setCopied] = useState(false);
  const fullAddress = '8/75, Gali No. 8, Industrial Area, Anand Parbat, Nai Basti, New Delhi - 110005';

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(fullAddress);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch (err) {
      // Fallback
      const el = document.createElement('textarea');
      el.value = fullAddress;
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const getMapsUrl = () => {
    return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent('8/75, Gali No. 8, Industrial Area, Anand Parbat, Nai Basti, New Delhi - 110005 Lucky Dhaba')}`;
  };

  return (
    <section className="py-12 bg-white" id="lucky-dhaba-address-map-section">
      <div className="max-w-6xl mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch">
          
          {/* Column 1: Timings & Opening Schedule */}
          <div className="flex flex-col justify-between bg-stone-900 text-stone-100 rounded-3xl p-6 sm:p-8 shadow-lg border border-stone-800">
            <div>
              <div className="flex items-center gap-2 mb-6">
                <Calendar className="w-5.5 h-5.5 text-amber-500" />
                <h3 className="text-xl font-bold tracking-tight text-white uppercase">
                  {t.timingsTitle}
                </h3>
              </div>

              {/* Schedule listing */}
              <div className="space-y-4">
                <div className="flex justify-between items-center border-b border-stone-800 pb-3">
                  <span className="font-bold text-sm text-stone-300">{t.tueToSun}</span>
                  <span className="text-sm font-extrabold text-amber-400 bg-amber-500/10 px-3 py-1 rounded-md">
                    09:00 AM - 11:00 PM
                  </span>
                </div>
                
                <div className="flex justify-between items-center border-b border-stone-800 pb-3">
                  <span className="font-bold text-sm text-stone-300">{t.monLunch}</span>
                  <span className="text-sm font-extrabold text-stone-400 bg-stone-800 px-3 py-1 rounded-md">
                    09:00 AM - 03:00 PM
                  </span>
                </div>

                <div className="flex justify-between items-center pb-1">
                  <span className="font-bold text-sm text-stone-300">{t.monDinner}</span>
                  <span className="text-sm font-extrabold text-stone-400 bg-stone-800 px-3 py-1 rounded-md">
                    07:00 PM - 09:00 PM
                  </span>
                </div>
              </div>
            </div>

            {/* Note on Operator */}
            <div className="mt-8 pt-6 border-t border-stone-800 flex items-center justify-between text-xs text-stone-400">
              <span>{lang === 'en' ? 'Authentic home food cooks fresh hourly.' : 'ताज़ा स्वादिष्ट रोटियां एवं तरीदार करी तैयार की जाती है।'}</span>
              <span className="font-bold text-amber-500">Rajendra Kushwaha ★</span>
            </div>
          </div>

          {/* Column 2: Location Card with Visual Maps Cue */}
          <div className="flex flex-col justify-between bg-stone-50 border border-stone-200 rounded-3xl p-6 sm:p-8 shadow-xs">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <MapPin className="w-5.5 h-5.5 text-amber-600 animate-bounce" />
                <h3 className="text-xl font-extrabold text-stone-900 tracking-tight">
                  {t.addressTitle}
                </h3>
              </div>

              <p className="text-stone-700 text-sm sm:text-base font-medium leading-relaxed mb-6">
                {fullAddress}
              </p>
            </div>

            {/* Simulated Map Visual Layout representing Anand Parbat block */}
            <div className="relative h-28 w-full bg-stone-200 rounded-2xl mb-6 overflow-hidden border border-stone-300 flex items-center justify-center">
              {/* Map grid representation */}
              <div className="absolute inset-0 opacity-20 bg-[linear-gradient(to_right,#808080_1px,transparent_1px),linear-gradient(to_bottom,#808080_1px,transparent_1px)] bg-[size:14px_24px]"></div>
              
              {/* Visual Landmark cue */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center">
                <div className="w-8 h-8 rounded-full bg-amber-600 text-white flex items-center justify-center shadow-md animate-pulse">
                  🍛
                </div>
                <span className="text-[10px] font-black text-stone-850 mt-1 uppercase tracking-wide bg-white/95 px-2 py-0.5 rounded-sm shadow-xs border">
                  Lucky Dhaba
                </span>
              </div>

              <div className="absolute bottom-2 right-2 flex items-center gap-1 bg-white/90 backdrop-blur-xs px-2.5 py-1 rounded-sm border text-[9px] font-extrabold text-stone-600 uppercase tracking-widest">
                <Compass className="w-3 h-3 text-stone-600 animate-spin" style={{ animationDuration: '4s' }} />
                <span>Nai Basti Area</span>
              </div>
            </div>

            {/* Nav and Copy tools */}
            <div className="flex flex-col sm:flex-row gap-3">
              {/* Google Navigation */}
              <a
                href={getMapsUrl()}
                target="_blank"
                rel="noreferrer"
                className="flex-1 flex items-center justify-center gap-2 bg-stone-900 hover:bg-stone-850 text-white font-bold py-3.5 px-4 rounded-xl text-xs transition-colors"
                id="maps-direction-button"
              >
                <ExternalLink className="w-4 h-4 text-amber-400" />
                <span>{t.getDirections}</span>
              </a>

              {/* Copy Address */}
              <button
                onClick={handleCopy}
                className={`flex-1 flex items-center justify-center gap-2 border py-3.5 px-4 rounded-xl text-xs font-bold transition-all ${
                  copied
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                    : 'bg-white border-stone-300 hover:border-stone-400 text-stone-700'
                }`}
                id="copy-address-button"
              >
                {copied ? <CheckCircle className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4 text-stone-500" />}
                <span>{copied ? t.copied : t.copyAddress}</span>
              </button>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
