import React from 'react';
import { Phone, Check, Clock, Globe, Award, Sparkles, MapPin } from 'lucide-react';
import { Language, DhabaStatus } from '../types';
import { TRANSLATIONS } from '../data';
import heroImage from '../assets/images/lucky_dhaba_hero_1781688770262.jpg';

interface HeaderProps {
  lang: Language;
  setLang: (lang: Language) => void;
  status: DhabaStatus;
}

export const Header: React.FC<HeaderProps> = ({ lang, setLang, status }) => {
  const t = TRANSLATIONS[lang];

  return (
    <header className="relative w-full overflow-hidden bg-stone-900 text-stone-100" id="lucky-dhaba-header">
      {/* Background Hero Banner with parallax overlay */}
      <div className="relative h-[250px] sm:h-[400px] w-full">
        {/* We use our generated high-quality banner image */}
        <div className="absolute inset-0 z-0 bg-stone-950">
          <img
            src={heroImage}
            alt="Delicious Authentic Indian food at Lucky Dhaba"
            className="w-full h-full object-cover opacity-80"
            referrerPolicy="no-referrer"
          />
          {/* Subtle gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-stone-900 via-stone-900/60 to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-r from-stone-950/80 via-transparent to-stone-950/80"></div>
        </div>

        {/* Top bar with Branding & Settings */}
        <div className="absolute top-0 inset-x-0 z-20 px-4 py-3 sm:py-4 max-w-6xl mx-auto flex items-center justify-between">
          <span className="flex items-center gap-1.5 bg-amber-500 text-stone-950 px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider shadow-md">
            <Sparkles className="w-3.5 h-3.5 fill-current" />
            Delhi Taste
          </span>

          {/* Bilingual Language Switcher */}
          <button
            onClick={() => setLang(lang === 'en' ? 'hi' : 'en')}
            className="flex items-center gap-1.5 bg-stone-900/90 hover:bg-stone-850 text-amber-400 hover:text-amber-300 border border-amber-500/30 font-medium px-3.5 py-1.5 rounded-lg text-xs tracking-wide transition-all shadow-lg active:scale-95 cursor-pointer"
            id="lang-toggle-button"
            title="भाषा बदलें / Change Language"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>{lang === 'en' ? 'हिन्दी में देखें' : 'View in English'}</span>
          </button>
        </div>

        {/* Bottom text inside the hero */}
        <div className="absolute bottom-0 inset-x-0 z-10 px-4 pb-6 sm:pb-8 max-w-6xl mx-auto flex flex-col justify-end h-full pointer-events-none">
          {/* Chef / Owner Badge overlay */}
          <div className="flex items-center gap-2 mb-2 self-start bg-amber-500/90 text-stone-950 backdrop-blur-xs font-bold text-[11px] sm:text-xs px-2.5 py-1 rounded-sm shadow-md uppercase tracking-wider pointer-events-auto">
            <Award className="w-3.5 h-3.5" />
            <span>{t.byOwner}</span>
          </div>

          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-white drop-shadow-md pointer-events-auto">
            {t.heroTitle}
          </h1>
          <p className="mt-1 sm:mt-2 text-stone-250 max-w-xl text-sm sm:text-lg font-medium tracking-wide drop-shadow-xs pointer-events-auto">
            {t.heroSubtitle}
          </p>
        </div>
      </div>

      {/* Primary info ribbon */}
      <div className="bg-stone-950 border-y border-stone-800 text-stone-300" id="timings-and-status-ribbon">
        <div className="max-w-6xl mx-auto px-4 py-3 sm:py-4 flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 sm:gap-4 text-xs sm:text-sm">
            {/* Live Operational Status Badge */}
            <div className={`flex items-center gap-2 border px-3 py-1.5 rounded-md font-semibold transition-all ${status.colorClass}`}>
              <span className={`w-2 h-2 rounded-full animate-ping ${status.isOpen ? 'bg-emerald-500' : 'bg-rose-500'}`} />
              <span>{lang === 'en' ? status.messageEn : status.messageHi}</span>
            </div>

            {/* Timings Quick Info */}
            <div className="flex items-center gap-1.5 text-stone-400">
              <Clock className="w-4 h-4 text-amber-500 shrink-0" />
              <span>
                {lang === 'en' ? 'Tue-Sun (09 AM - 11 PM)' : 'मंगल-रवि (सुबह 09 - रात 11)'}
              </span>
            </div>

            {/* Location Quick Info */}
            <div className="flex items-center gap-1.5 text-stone-400">
              <MapPin className="w-4 h-4 text-amber-500 shrink-0" />
              <span>Anand Parbat, Delhi</span>
            </div>
          </div>

          {/* Quick Call Button */}
          <a
            href="tel:+917982560692"
            className="w-full md:w-auto flex items-center justify-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-stone-950 font-bold px-5 py-2.5 rounded-lg text-sm transition-all shadow-md hover:shadow-amber-500/10 active:scale-98"
            id="call-now-button"
          >
            <Phone className="w-4 h-4" />
            <span>{t.quickCall}</span>
          </a>
        </div>
      </div>
    </header>
  );
};
