import React from 'react';
import { Star, MessageSquare } from 'lucide-react';
import { Language } from '../types';
import { TESTIMONIALS, TRANSLATIONS } from '../data';

interface TestimonialsProps {
  lang: Language;
}

export const Testimonials: React.FC<TestimonialsProps> = ({ lang }) => {
  const t = TRANSLATIONS[lang];

  return (
    <section className="py-12 bg-stone-50 border-b border-stone-200" id="lucky-dhaba-reviews-section">
      <div className="max-w-6xl mx-auto px-4">
        {/* Title */}
        <div className="text-center mb-10">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-900 tracking-tight flex items-center justify-center gap-2">
            <MessageSquare className="w-5.5 h-5.5 text-amber-500 fill-amber-500/10" />
            <span>{t.reviewsTitle}</span>
          </h2>
          <div className="w-12 h-1 bg-amber-500 mx-auto mt-3 rounded-full"></div>
        </div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((review) => {
            const role = lang === 'en' ? review.roleEn : review.roleHi;
            const comment = lang === 'en' ? review.commentEn : review.commentHi;

            return (
              <div
                key={review.id}
                className="bg-white border border-stone-200 rounded-2xl p-6 shadow-xs flex flex-col justify-between"
                id={`customer-review-${review.id}`}
              >
                {/* Header with stars & rating */}
                <div>
                  <div className="flex items-center gap-1 text-amber-500 mb-3">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current text-amber-500" />
                    ))}
                  </div>

                  <p className="text-stone-700 text-xs sm:text-sm italic leading-relaxed mb-6">
                    "{comment}"
                  </p>
                </div>

                {/* Author Info */}
                <div className="flex items-center justify-between pt-4 border-t border-stone-150 mt-auto">
                  <div>
                    <h4 className="font-extrabold text-stone-900 text-sm">{review.name}</h4>
                    <span className="text-[11px] font-bold text-amber-600 block mt-0.5">{role}</span>
                  </div>
                  <span className="text-[10px] text-stone-400 font-semibold uppercase tracking-wider bg-stone-100 px-2 py-0.5 rounded-sm">
                    {review.date}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
