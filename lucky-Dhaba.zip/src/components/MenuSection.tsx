import React from 'react';
import { Plus, Minus, Flame, Users, Sparkles, Scale } from 'lucide-react';
import { Language, MenuItem, CartItem } from '../types';
import { MENU_ITEMS, TRANSLATIONS } from '../data';

interface MenuSectionProps {
  lang: Language;
  cart: CartItem[];
  onUpdateQuantity: (item: MenuItem, quantity: number) => void;
}

export const MenuSection: React.FC<MenuSectionProps> = ({ lang, cart, onUpdateQuantity }) => {
  const t = TRANSLATIONS[lang];

  const getQuantity = (itemId: string): number => {
    const cartItem = cart.find((item) => item.menuItem.id === itemId);
    return cartItem ? cartItem.quantity : 0;
  };

  return (
    <section className="py-10 px-4" id="lucky-dhaba-menu-section">
      <div className="max-w-6xl mx-auto">
        {/* Title Group */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-1.5 text-amber-600 bg-amber-500/10 px-3 py-1 rounded-full text-xs font-semibold mb-3">
            <Flame className="w-3.5 h-3.5 fill-current animate-pulse" />
            <span>{lang === 'en' ? 'Fresh Every Day' : 'रोज़ाना एकदम ताज़ा'}</span>
          </div>
          <h2 className="text-3xl font-extrabold text-stone-900 tracking-tight sm:text-4xl">
            {t.menuTitle}
          </h2>
          <p className="mt-2.5 text-stone-600 text-sm sm:text-base max-w-xl mx-auto">
            {t.menuSubtitle}
          </p>
          <div className="w-20 h-1 bg-amber-500 mx-auto mt-4 rounded-full"></div>
        </div>

        {/* Menu Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {MENU_ITEMS.map((item) => {
            const quantity = getQuantity(item.id);
            const name = lang === 'en' ? item.nameEn : item.nameHi;
            const desc = lang === 'en' ? item.descriptionEn : item.descriptionHi;
            const tag = lang === 'en' ? item.tagEn : item.tagHi;

            return (
              <div
                key={item.id}
                className={`relative flex flex-col justify-between bg-white border rounded-2xl p-5 sm:p-6 transition-all duration-350 shadow-xs hover:shadow-lg hover:-translate-y-1 ${
                  quantity > 0
                    ? 'border-amber-500 ring-2 ring-amber-500/10 bg-amber-500/[0.01]'
                    : 'border-stone-200'
                }`}
                id={`menu-card-${item.id}`}
              >
                {/* Floating Tag */}
                <div className="flex items-center justify-between mb-4">
                  <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold tracking-wide uppercase ${
                    quantity > 0 ? 'bg-amber-500 text-stone-950' : 'bg-stone-100 text-stone-600'
                  }`}>
                    {tag}
                  </span>
                  <span className="text-2xl" role="img" aria-label={name}>
                    {item.image}
                  </span>
                </div>

                <div>
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="text-lg sm:text-xl font-bold text-stone-900 line-clamp-1">
                      {name}
                    </h3>
                    <div className="text-amber-600 font-extrabold text-lg sm:text-xl shrink-0">
                      ₹{item.price}
                    </div>
                  </div>

                  <p className="mt-2 text-stone-550 text-xs sm:text-sm leading-relaxed mb-6">
                    {desc}
                  </p>
                </div>

                {/* Card footer: add action / counter */}
                <div className="pt-4 border-t border-stone-100 flex items-center justify-between">
                  {/* Free Onions / Salad label standard of Indian Dhaba */}
                  <span className="text-[11px] sm:text-xs text-stone-500 flex items-center gap-1 font-medium">
                    <Sparkles className="w-3 h-3 text-amber-500 shrink-0" />
                    {lang === 'en' ? '+ Free Salad & Cold Water' : '+ मुफ्त सलाद और ठंडा पानी'}
                  </span>

                  {quantity === 0 ? (
                    <button
                      onClick={() => onUpdateQuantity(item, 1)}
                      className="flex items-center gap-1 border border-amber-500 hover:bg-amber-500 hover:text-stone-950 text-amber-600 font-bold px-4 py-1.5 rounded-lg text-xs tracking-wide transition-all duration-200 hover:shadow-xs active:scale-95 cursor-pointer"
                      id={`btn-add-${item.id}`}
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>{t.addPlate}</span>
                    </button>
                  ) : (
                    <div className="flex items-center bg-amber-500 text-stone-950 rounded-lg p-0.5 shadow-sm">
                      <button
                        onClick={() => onUpdateQuantity(item, quantity - 1)}
                        className="p-1 px-2.5 hover:bg-amber-400 font-bold transition-colors rounded-l-md"
                        id={`btn-dec-${item.id}`}
                        aria-label="Decrease quantity"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="font-extrabold text-xs px-3 min-w-[20px] text-center" id={`qty-${item.id}`}>
                        {quantity}
                      </span>
                      <button
                        onClick={() => onUpdateQuantity(item, quantity + 1)}
                        className="p-1 px-2.5 hover:bg-amber-400 font-bold transition-colors rounded-r-md"
                        id={`btn-inc-${item.id}`}
                        aria-label="Increase quantity"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
