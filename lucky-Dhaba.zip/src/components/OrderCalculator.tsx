import React from 'react';
import { ShoppingBag, ArrowRight, MessageSquareCode, PhoneCall, Trash2, Heart, Sparkles, CheckCircle2 } from 'lucide-react';
import { Language, CartItem, MenuItem } from '../types';
import { TRANSLATIONS } from '../data';
import { formatWhatsAppOrderLink } from '../utils';

interface OrderCalculatorProps {
  lang: Language;
  cart: CartItem[];
  serviceMode: 'dinein' | 'takeaway';
  setServiceMode: (mode: 'dinein' | 'takeaway') => void;
  instructions: string;
  setInstructions: (text: string) => void;
  onClearCart: () => void;
  onRemoveItem: (item: MenuItem) => void;
}

export const OrderCalculator: React.FC<OrderCalculatorProps> = ({
  lang,
  cart,
  serviceMode,
  setServiceMode,
  instructions,
  setInstructions,
  onClearCart,
  onRemoveItem
}) => {
  const t = TRANSLATIONS[lang];
  const isEmpty = cart.length === 0;

  const totalAmount = cart.reduce((acc, item) => acc + item.menuItem.price * item.quantity, 0);

  const handleWhatsAppOrder = () => {
    // Generate the URL and open in a new window/tab as specified by platform constraints (popups may get blocked, but standard target="_blank" link is perfectly safe)
    const link = formatWhatsAppOrderLink(cart, serviceMode, instructions);
    window.open(link, '_blank', 'noreferrer');
  };

  return (
    <section className="py-10 px-4 bg-stone-50 border-t border-b border-stone-200" id="lucky-dhaba-order-section">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-900 tracking-tight flex items-center justify-center gap-2">
            <ShoppingBag className="w-6 h-6 text-amber-500" />
            <span>{t.yourPlate}</span>
          </h2>
          <div className="w-16 h-1 bg-amber-500 mx-auto mt-3 rounded-full"></div>
        </div>

        {isEmpty ? (
          /* Empty Plate Design */
          <div className="bg-white border-2 border-dashed border-stone-200 rounded-3xl p-10 text-center max-w-lg mx-auto shadow-xs">
            <div className="text-5xl mb-4 text-stone-300">🍛</div>
            <p className="text-stone-500 font-medium text-sm sm:text-base leading-relaxed">
              {t.emptyPlate}
            </p>
          </div>
        ) : (
          /* Populated Cart (Steel Thali vibe) */
          <div className="bg-white border border-stone-200 rounded-3xl shadow-xl overflow-hidden">
            {/* Header / Actions of Thali */}
            <div className="bg-stone-900 text-stone-100 px-6 py-4 flex items-center justify-between">
              <span className="flex items-center gap-2 font-bold tracking-wide text-xs uppercase text-amber-400">
                <Sparkles className="w-4 h-4 fill-current animate-pulse text-amber-400" />
                {lang === 'en' ? 'Freshly Packed & Tempered' : 'गर्मागर्म असली ढाबा स्वाद'}
              </span>
              <button
                onClick={onClearCart}
                className="flex items-center gap-1.5 text-stone-400 hover:text-rose-400 text-xs px-2.5 py-1 rounded-md transition-colors"
                id="clear-all-plate-items"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{lang === 'en' ? 'Reset Plate' : 'थाली खाली करें'}</span>
              </button>
            </div>

            <div className="p-5 sm:p-8">
              {/* Itemized list */}
              <div className="space-y-4">
                {cart.map((item) => {
                  const name = lang === 'en' ? item.menuItem.nameEn : item.menuItem.nameHi;
                  const itemTotal = item.menuItem.price * item.quantity;

                  return (
                    <div
                      key={item.menuItem.id}
                      className="flex items-center justify-between border-b border-stone-100 pb-3 last:border-0 last:pb-0"
                      id={`cart-item-${item.menuItem.id}`}
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="text-xl" role="img" aria-label={name}>
                          {item.menuItem.image}
                        </span>
                        <div>
                          <h4 className="font-bold text-stone-850 text-sm sm:text-base">
                            {name}
                          </h4>
                          <div className="text-xs text-stone-500 mt-0.5">
                            ₹{item.menuItem.price} × {item.quantity}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-4">
                        <span className="font-extrabold text-stone-900 text-sm sm:text-base shrink-0">
                          ₹{itemTotal}
                        </span>
                        <button
                          onClick={() => onRemoveItem(item.menuItem)}
                          className="text-stone-400 hover:text-rose-600 transition-colors p-1"
                          aria-label="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Special packing / dine-in selection */}
              <div className="mt-8 pt-6 border-t border-stone-200">
                <label className="block text-sm font-extrabold text-stone-850 mb-3 uppercase tracking-wider text-left">
                  {t.packingOption}
                </label>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Dine In Button */}
                  <button
                    type="button"
                    onClick={() => setServiceMode('dinein')}
                    className={`flex items-center gap-3 p-4 rounded-xl border text-left transition-all ${
                      serviceMode === 'dinein'
                        ? 'border-amber-500 bg-amber-500/[0.03] ring-1 ring-amber-500/20'
                        : 'border-stone-200 hover:border-stone-300 hover:bg-stone-50'
                    }`}
                  >
                    <div className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 ${
                      serviceMode === 'dinein' ? 'border-amber-500 bg-amber-500 text-white' : 'border-stone-300'
                    }`}>
                      {serviceMode === 'dinein' && <div className="w-2.5 h-2.5 bg-stone-900 rounded-full" />}
                    </div>
                    <div>
                      <div className="font-bold text-stone-800 text-sm">{t.dineIn}</div>
                      <div className="text-xs text-stone-500 mt-0.5">
                        {lang === 'en' ? 'Comfortable clean seating setup at Dhaba.' : 'बैठने की बढ़िया व्यवस्था।'}
                      </div>
                    </div>
                  </button>

                  {/* Takeaway Packing Button */}
                  <button
                    type="button"
                    onClick={() => setServiceMode('takeaway')}
                    className={`flex items-center gap-3 p-4 rounded-xl border text-left transition-all ${
                      serviceMode === 'takeaway'
                        ? 'border-amber-500 bg-amber-500/[0.03] ring-1 ring-amber-500/20'
                        : 'border-stone-200 hover:border-stone-300 hover:bg-stone-50'
                    }`}
                  >
                    <div className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 ${
                      serviceMode === 'takeaway' ? 'border-amber-500 bg-amber-500 text-white' : 'border-stone-300'
                    }`}>
                      {serviceMode === 'takeaway' && <div className="w-2.5 h-2.5 bg-stone-900 rounded-full" />}
                    </div>
                    <div>
                      <div className="font-bold text-stone-800 text-sm">{t.takeaway}</div>
                      <div className="text-xs text-stone-500 mt-0.5">
                        {lang === 'en' ? 'Sturdy hygienic spill-proof package.' : 'पैकिंग की पूरी सुविधा।'}
                      </div>
                    </div>
                  </button>
                </div>
              </div>

              {/* Cooking Instructions Textbox */}
              <div className="mt-6">
                <label htmlFor="cooking-notes" className="block text-sm font-extrabold text-stone-850 mb-2 uppercase tracking-wider text-left">
                  {t.specialNote}
                </label>
                <textarea
                  id="cooking-notes"
                  rows={2}
                  value={instructions}
                  onChange={(e) => setInstructions(e.target.value)}
                  placeholder={lang === 'en' ? 'E.g., Make it spicy, less oil, extra onions...' : 'उदा. कम तीखा बनाएं, प्याज ज़्यादा देना, नीम्बू भी डालना...'}
                  className="w-full text-stone-800 text-sm border border-stone-250 rounded-xl p-3 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/15 focus:outline-hidden transition-all bg-stone-50/50"
                />
              </div>

              {/* Total Calculation & Cold Water Incentive */}
              <div className="mt-8 pt-6 border-t border-stone-200">
                <div className="bg-teal-500/10 text-teal-700 border border-teal-500/20 rounded-xl p-3 mb-6 flex items-center justify-between text-xs sm:text-sm font-semibold">
                  <span>{t.freeWaterBadge}</span>
                  <span className="text-xs bg-teal-600 text-white px-2 py-0.5 rounded-sm uppercase tracking-wide">
                    {lang === 'en' ? 'Free Gift' : 'एकदम फ्री'}
                  </span>
                </div>

                <div className="flex items-center justify-between text-stone-900 mb-6">
                  <span className="text-lg font-bold">{t.total}</span>
                  <span className="text-3xl font-black text-amber-600">₹{totalAmount}</span>
                </div>

                {/* Submit Actions */}
                <div className="space-y-4">
                  {/* WhatsApp Submission Pin */}
                  <button
                    onClick={handleWhatsAppOrder}
                    className="w-full flex items-center justify-center gap-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold py-4 px-6 rounded-xl text-base shadow-lg hover:shadow-emerald-500/20 active:scale-98 transition-all cursor-pointer"
                    id="whatsapp-submit-plate-order"
                  >
                    <MessageSquareCode className="w-5.5 h-5.5" />
                    <span>{t.whatsappOrderButton}</span>
                    <ArrowRight className="w-5 h-5" />
                  </button>

                  <div className="flex items-center justify-center gap-3">
                    <div className="grow h-px bg-stone-200"></div>
                    <span className="text-xs font-bold text-stone-400 capitalize">{t.or}</span>
                    <div className="grow h-px bg-stone-200"></div>
                  </div>

                  {/* Direct Phone Call Hook */}
                  <a
                    href="tel:+917982560692"
                    className="w-full flex items-center justify-center gap-2 bg-stone-900 hover:bg-stone-850 text-white font-extrabold py-3.5 px-6 rounded-xl text-sm border border-stone-800 transition-all active:scale-98"
                    id="call-submit-plate-order"
                  >
                    <PhoneCall className="w-4.5 h-4.5 text-amber-400" />
                    <span>{t.callOrderButton}</span>
                  </a>

                  {/* Bottom Safety Info disclosure */}
                  <p className="text-[11px] text-stone-400 text-center leading-relaxed">
                    🙋‍♂️ {t.openWarning}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
