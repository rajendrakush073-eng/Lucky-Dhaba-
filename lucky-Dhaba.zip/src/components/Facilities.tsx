import React from 'react';
import { Sparkles, GlassWater, Utensils, Box } from 'lucide-react';
import { Language } from '../types';
import { TRANSLATIONS } from '../data';

interface FacilitiesProps {
  lang: Language;
}

export const Facilities: React.FC<FacilitiesProps> = ({ lang }) => {
  const t = TRANSLATIONS[lang];

  return (
    <section className="py-12 bg-white" id="lucky-dhaba-facilities-section">
      <div className="max-w-6xl mx-auto px-4">
        {/* Title Group */}
        <div className="text-center mb-10">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-900 tracking-tight">
            {t.facilitiesTitle}
          </h2>
          <div className="w-12 h-1 bg-amber-500 mx-auto mt-3 rounded-full"></div>
        </div>

        {/* Facilities Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Facility 1: Free Cold Water */}
          <div className="flex flex-col items-center text-center p-6 border border-stone-100 rounded-2xl bg-stone-50/50 hover:bg-stone-50 transition-colors">
            <div className="w-12 h-12 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-600 mb-4 ring-4 ring-blue-500/5">
              <GlassWater className="w-6 h-6" />
            </div>
            <h3 className="text-base sm:text-lg font-bold text-stone-900 mb-2">
              {t.facilityWater}
            </h3>
            <p className="text-xs sm:text-sm text-stone-600 leading-relaxed max-w-xs">
              {t.facilityWaterDesc}
            </p>
          </div>

          {/* Facility 2: Dine In Seating */}
          <div className="flex flex-col items-center text-center p-6 border border-stone-100 rounded-2xl bg-stone-50/50 hover:bg-stone-50 transition-colors">
            <div className="w-12 h-12 rounded-full bg-amber-500/10 flex items-center justify-center text-amber-600 mb-4 ring-4 ring-amber-500/5">
              <Utensils className="w-6 h-6" />
            </div>
            <h3 className="text-base sm:text-lg font-bold text-stone-900 mb-2">
              {t.facilityDineIn}
            </h3>
            <p className="text-xs sm:text-sm text-stone-600 leading-relaxed max-w-xs">
              {t.facilityDineInDesc}
            </p>
          </div>

          {/* Facility 3: Takeaway Packing */}
          <div className="flex flex-col items-center text-center p-6 border border-stone-100 rounded-2xl bg-stone-50/50 hover:bg-stone-50 transition-colors">
            <div className="w-12 h-12 rounded-full bg-stone-900/5 flex items-center justify-center text-stone-850 mb-4 ring-4 ring-stone-900/2">
              <Box className="w-6 h-6 text-stone-800" />
            </div>
            <h3 className="text-base sm:text-lg font-bold text-stone-900 mb-2">
              {t.facilityPacking}
            </h3>
            <p className="text-xs sm:text-sm text-stone-600 leading-relaxed max-w-xs">
              {t.facilityPackingDesc}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
