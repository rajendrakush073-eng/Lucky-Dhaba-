import React from 'react';
import { ShieldCheck, Heart, Sparkles, Award } from 'lucide-react';
import { Language } from '../types';
import { TRANSLATIONS } from '../data';

interface AboutSectionProps {
  lang: Language;
}

export const AboutSection: React.FC<AboutSectionProps> = ({ lang }) => {
  const t = TRANSLATIONS[lang];

  return (
    <section className="py-14 bg-stone-900 text-stone-200 border-t border-stone-950" id="lucky-dhaba-story-section">
      <div className="max-w-4xl mx-auto px-4">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-amber-500/10 text-amber-400 mb-3">
            <Award className="w-6 h-6" />
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            {t.aboutUs}
          </h2>
          <div className="w-16 h-1 bg-amber-500 mx-auto mt-3 rounded-full"></div>
        </div>

        <div className="bg-stone-850 border border-stone-800 rounded-3xl p-6 sm:p-10 shadow-xl relative overflow-hidden">
          {/* Accent Glow details */}
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-2xl"></div>
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-amber-500/5 rounded-full blur-2xl"></div>

          <p className="text-stone-300 text-sm sm:text-base leading-relaxed text-center sm:text-justify font-medium">
            {t.aboutUsDesc}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-8 pt-8 border-t border-stone-800/80 text-center">
            {/* Aspect 1 */}
            <div className="flex flex-col items-center">
              <Heart className="w-5 h-5 text-amber-500 mb-2" />
              <h4 className="font-extrabold text-white text-xs sm:text-sm uppercase tracking-wider">
                {lang === 'en' ? 'Made with Love' : 'प्यार से परोसा'}
              </h4>
              <p className="text-[10px] sm:text-xs text-stone-400 mt-1">
                {lang === 'en' ? 'Home-matured spice blends' : 'घर के पिसे शुद्ध मसाले'}
              </p>
            </div>

            {/* Aspect 2 */}
            <div className="flex flex-col items-center">
              <ShieldCheck className="w-5 h-5 text-emerald-500 mb-2" />
              <h4 className="font-extrabold text-white text-xs sm:text-sm uppercase tracking-wider">
                {lang === 'en' ? '100% Hygienic' : 'ताज़गी और स्वच्छता'}
              </h4>
              <p className="text-[10px] sm:text-xs text-stone-400 mt-1">
                {lang === 'en' ? 'Fresh veggies & mineral water' : 'रोजाना ताजी सब्जियां'}
              </p>
            </div>

            {/* Aspect 3 */}
            <div className="flex flex-col items-center">
              <Sparkles className="w-5 h-5 text-amber-500 mb-2" />
              <h4 className="font-extrabold text-white text-xs sm:text-sm uppercase tracking-wider">
                {lang === 'en' ? 'Dhaba Authenticity' : 'असली ढाबा मजा'}
              </h4>
              <p className="text-[10px] sm:text-xs text-stone-400 mt-1">
                {lang === 'en' ? 'Slow-cooked traditional methods' : 'धीमी आँच पर पकाया रसीला भोजन'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
